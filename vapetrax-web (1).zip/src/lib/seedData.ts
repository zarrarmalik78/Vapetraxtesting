import { collection, addDoc, serverTimestamp, getDocs, deleteDoc, doc, writeBatch } from 'firebase/firestore';
import { db } from '../firebase';

export const seedSampleData = async (shopId: string) => {
  try {
    if (!shopId) throw new Error('shopId is required for seeding data');
    const batch = writeBatch(db);

    // 1. Sample Products
    const products = [
      { name: 'Vaporesso XROS 3', brand: 'Vaporesso', category: 'device', costPrice: 4500, sellingPrice: 6500, stockQuantity: 15, minStockLevel: 5, unit: 'piece', shopId, createdAt: serverTimestamp() },
      { name: 'Caliburn G2', brand: 'Uwell', category: 'device', costPrice: 3800, sellingPrice: 5500, stockQuantity: 8, minStockLevel: 3, unit: 'piece', shopId, createdAt: serverTimestamp() },
      { name: 'Geekvape Aegis Legend 2', brand: 'Geekvape', category: 'device', costPrice: 12000, sellingPrice: 16500, stockQuantity: 4, minStockLevel: 2, unit: 'piece', shopId, createdAt: serverTimestamp() },
      { name: 'XROS Series Pods 0.6ohm', brand: 'Vaporesso', category: 'coil', costPrice: 800, sellingPrice: 1200, stockQuantity: 50, minStockLevel: 10, unit: 'piece', shopId, createdAt: serverTimestamp() },
      { name: 'Caliburn G Coils 0.8ohm', brand: 'Uwell', category: 'coil', costPrice: 650, sellingPrice: 950, stockQuantity: 30, minStockLevel: 10, unit: 'piece', shopId, createdAt: serverTimestamp() },
      { name: 'V God Cubano 30ml', brand: 'V God', category: 'e-liquid', costPrice: 1800, sellingPrice: 2800, stockQuantity: 20, minStockLevel: 5, unit: 'bottle', bottleSize: '30', nicotineLevel: 25, shopId, createdAt: serverTimestamp() },
      { name: 'Skwezed Green Apple 30ml', brand: 'Skwezed', category: 'e-liquid', costPrice: 1600, sellingPrice: 2500, stockQuantity: 12, minStockLevel: 5, unit: 'bottle', bottleSize: '30', nicotineLevel: 35, shopId, createdAt: serverTimestamp() },
      { name: 'Ruthless Grape Drank 60ml', brand: 'Ruthless', category: 'e-liquid', costPrice: 2200, sellingPrice: 3500, stockQuantity: 10, minStockLevel: 3, unit: 'bottle', bottleSize: '60', nicotineLevel: 3, shopId, createdAt: serverTimestamp() },
    ];

    // 2. Sample Customers
    const customers = [
      { name: 'Ahmed Khan', phone: '03001234567', email: 'ahmed@example.com', creditBalance: 1500, shopId, createdAt: serverTimestamp() },
      { name: 'Sara Ali', phone: '03217654321', email: 'sara@example.com', creditBalance: 0, shopId, createdAt: serverTimestamp() },
      { name: 'Zainab Bibi', phone: '03339876543', email: 'zainab@example.com', creditBalance: 500, shopId, createdAt: serverTimestamp() },
    ];

    // 3. Sample Suppliers
    const suppliers = [
      { name: 'Vape Wholesale PK', contactPerson: 'Kamran', phone: '03451122334', email: 'wholesale@vapepk.com', address: 'Karachi, Pakistan', shopId, createdAt: serverTimestamp() },
      { name: 'Cloud Distribution', contactPerson: 'Bilal', phone: '03124455667', email: 'info@clouddist.com', address: 'Lahore, Pakistan', shopId, createdAt: serverTimestamp() },
    ];

    // 4. Sample Expenses
    const expenses = [
      { title: 'Shop Rent - March', amount: 45000, category: 'Rent', date: serverTimestamp(), notes: 'Paid via bank transfer', shopId, createdAt: serverTimestamp() },
      { title: 'Electricity Bill', amount: 12500, category: 'Utilities', date: serverTimestamp(), notes: 'March bill', shopId, createdAt: serverTimestamp() },
      { title: 'Staff Salary - Ali', amount: 25000, category: 'Salary', date: serverTimestamp(), notes: 'Monthly salary', shopId, createdAt: serverTimestamp() },
    ];

    // Add Products
    const productRefs: any[] = [];
    for (const p of products) {
      const ref = await addDoc(collection(db, 'products'), p);
      productRefs.push({ id: ref.id, ...p });
    }

    // Add Customers
    const customerRefs: any[] = [];
    for (const c of customers) {
      const ref = await addDoc(collection(db, 'customers'), c);
      customerRefs.push({ id: ref.id, ...c });
    }

    // Add Suppliers
    for (const s of suppliers) {
      await addDoc(collection(db, 'suppliers'), s);
    }

    // Add Expenses
    for (const e of expenses) {
      await addDoc(collection(db, 'expenses'), e);
    }

    // 5. Sample Sales
    const sales = [
      {
        customerId: customerRefs[0].id,
        shopId,
        items: [
          { productId: productRefs[0].id, productName: productRefs[0].name, quantity: 1, unitPrice: productRefs[0].sellingPrice, totalPrice: productRefs[0].sellingPrice, saleType: 'full_bottle' }
        ],
        totalAmount: productRefs[0].sellingPrice,
        paymentMethod: 'cash',
        saleDate: serverTimestamp(),
        createdAt: serverTimestamp()
      },
      {
        customerId: customerRefs[1].id,
        shopId,
        items: [
          { productId: productRefs[3].id, productName: productRefs[3].name, quantity: 2, unitPrice: productRefs[3].sellingPrice, totalPrice: productRefs[3].sellingPrice * 2, saleType: 'full_bottle' },
          { productId: productRefs[5].id, productName: productRefs[5].name, quantity: 1, unitPrice: productRefs[5].sellingPrice, totalPrice: productRefs[5].sellingPrice, saleType: 'full_bottle' }
        ],
        totalAmount: (productRefs[3].sellingPrice * 2) + productRefs[5].sellingPrice,
        paymentMethod: 'online',
        saleDate: serverTimestamp(),
        createdAt: serverTimestamp()
      },
      {
        customerId: customerRefs[2].id,
        shopId,
        items: [
          { productId: productRefs[1].id, productName: productRefs[1].name, quantity: 1, unitPrice: productRefs[1].sellingPrice, totalPrice: productRefs[1].sellingPrice, saleType: 'full_bottle' }
        ],
        totalAmount: productRefs[1].sellingPrice,
        paymentMethod: 'credit',
        saleDate: serverTimestamp(),
        createdAt: serverTimestamp()
      }
    ];

    for (const s of sales) {
      await addDoc(collection(db, 'sales'), s);
    }

    // 6. Sample Inventory Logs
    for (const p of productRefs) {
      await addDoc(collection(db, 'inventoryLogs'), {
        productId: p.id,
        shopId,
        action: 'restock',
        quantityChange: p.stockQuantity,
        notes: 'Initial stock seeding',
        createdAt: serverTimestamp()
      });
    }

    return true;
  } catch (error) {
    console.error('Error seeding data:', error);
    throw error;
  }
};
