import React, { useState, useEffect } from 'react';
import { 
  Settings as SettingsIcon, 
  Store, 
  Palette, 
  FileText, 
  Shield, 
  Save, 
  Upload, 
  Trash2, 
  Plus, 
  X,
  User,
  Mail,
  Phone,
  MapPin,
  Globe,
  Image as ImageIcon
} from 'lucide-react';
import { useFirestore, useDocument } from '../hooks/useFirestore';
import { db } from '../firebase';
import { doc, setDoc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';
import { formatCurrency, cn } from '../lib/utils';
import LoadingSpinner from '../components/ui/LoadingSpinner';

const Settings: React.FC = () => {
  const { shopId } = useAuth();
  const { document: settings, loading } = useDocument<any>('settings', shopId || 'shop_settings');
  const [activeTab, setActiveTab] = useState('shop');
  const [formData, setFormData] = useState<any>(null);

  useEffect(() => {
    if (settings) {
      setFormData(settings);
    } else {
      setFormData({
        shopName: 'My Shop',
        shopLogo: '',
        shopAddress: '',
        shopPhone: '',
        shopEmail: '',
        shopWebsite: '',
        currency: 'Rs',
        invoicePrefix: 'INV-',
        invoiceFooter: 'Thank you for your business!',
        lowStockThreshold: 5,
        themeColor: '#8b5cf6',
        accentColor: '#d946ef'
      });
    }
  }, [settings]);

  const handleSave = async () => {
    if (!shopId) return;
    try {
      await setDoc(doc(db, 'settings', shopId), {
        ...formData,
        shopId,
        updatedAt: serverTimestamp()
      });
      toast.success('Settings updated successfully');
    } catch (error) {
      toast.error('Failed to update settings');
    }
  };

  if (loading || !formData) return <LoadingSpinner />;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
            <SettingsIcon size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">System Settings</h1>
            <p className="text-slate-500 text-sm">Configure your shop details, branding, and system preferences</p>
          </div>
        </div>
        <button 
          onClick={handleSave}
          className="flex items-center gap-2 px-6 py-2.5 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs uppercase tracking-widest rounded-xl shadow-lg shadow-violet-600/20 transition-all active:scale-[0.98]"
        >
          <Save size={20} />
          Save Changes
        </button>
      </header>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Settings Navigation */}
        <div className="lg:w-72 space-y-2">
          <SettingsNavButton 
            active={activeTab === 'shop'} 
            onClick={() => setActiveTab('shop')} 
            icon={<Store size={18} />} 
            label="Shop Profile" 
          />
          <SettingsNavButton 
            active={activeTab === 'branding'} 
            onClick={() => setActiveTab('branding')} 
            icon={<Palette size={18} />} 
            label="Branding" 
          />
          <SettingsNavButton 
            active={activeTab === 'invoice'} 
            onClick={() => setActiveTab('invoice')} 
            icon={<FileText size={18} />} 
            label="Invoice Template" 
          />
          <SettingsNavButton 
            active={activeTab === 'system'} 
            onClick={() => setActiveTab('system')} 
            icon={<SettingsIcon size={18} />} 
            label="System Config" 
          />
          <SettingsNavButton 
            active={activeTab === 'security'} 
            onClick={() => setActiveTab('security')} 
            icon={<Shield size={18} />} 
            label="Security" 
          />
        </div>

        {/* Settings Content */}
        <div className="flex-1 glass-card p-8 min-h-[600px]">
          {activeTab === 'shop' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
                <div className="w-10 h-10 rounded-xl bg-violet-50 flex items-center justify-center text-violet-600">
                  <Store size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">Shop Profile</h3>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Store size={14} className="text-violet-600" />
                    Shop Name
                  </label>
                  <input 
                    type="text" 
                    value={formData.shopName}
                    onChange={(e) => setFormData({...formData, shopName: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Phone size={14} className="text-violet-600" />
                    Phone Number
                  </label>
                  <input 
                    type="text" 
                    value={formData.shopPhone}
                    onChange={(e) => setFormData({...formData, shopPhone: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Mail size={14} className="text-violet-600" />
                    Email Address
                  </label>
                  <input 
                    type="email" 
                    value={formData.shopEmail}
                    onChange={(e) => setFormData({...formData, shopEmail: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Globe size={14} className="text-violet-600" />
                    Website
                  </label>
                  <input 
                    type="text" 
                    value={formData.shopWebsite}
                    onChange={(e) => setFormData({...formData, shopWebsite: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                </div>
                <div className="md:col-span-2 space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <MapPin size={14} className="text-violet-600" />
                    Physical Address
                  </label>
                  <textarea 
                    value={formData.shopAddress}
                    onChange={(e) => setFormData({...formData, shopAddress: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all h-32 resize-none"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'branding' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
                <div className="w-10 h-10 rounded-xl bg-fuchsia-50 flex items-center justify-center text-fuchsia-600">
                  <Palette size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">Branding & Visuals</h3>
              </div>
              <div className="space-y-8">
                <div className="space-y-4">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <ImageIcon size={14} className="text-fuchsia-600" />
                    Shop Logo URL
                  </label>
                  <div className="flex items-center gap-6">
                    <div className="w-32 h-32 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center overflow-hidden shadow-inner">
                      {formData.shopLogo ? (
                        <img src={formData.shopLogo} alt="Logo" className="w-full h-full object-contain p-2" />
                      ) : (
                        <Store size={40} className="text-slate-200" />
                      )}
                    </div>
                    <div className="flex-1 space-y-3">
                      <input 
                        type="text" 
                        placeholder="https://example.com/logo.png"
                        value={formData.shopLogo}
                        onChange={(e) => setFormData({...formData, shopLogo: e.target.value})}
                        className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                      />
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Provide a direct URL to your shop's logo image</p>
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Theme Primary Color</label>
                    <div className="flex items-center gap-3">
                      <input 
                        type="color" 
                        value={formData.themeColor}
                        onChange={(e) => setFormData({...formData, themeColor: e.target.value})}
                        className="w-12 h-12 rounded-xl bg-transparent border-none cursor-pointer shadow-sm"
                      />
                      <input 
                        type="text" 
                        value={formData.themeColor}
                        onChange={(e) => setFormData({...formData, themeColor: e.target.value})}
                        className="flex-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-mono font-bold focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                      />
                    </div>
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Accent Color</label>
                    <div className="flex items-center gap-3">
                      <input 
                        type="color" 
                        value={formData.accentColor}
                        onChange={(e) => setFormData({...formData, accentColor: e.target.value})}
                        className="w-12 h-12 rounded-xl bg-transparent border-none cursor-pointer shadow-sm"
                      />
                      <input 
                        type="text" 
                        value={formData.accentColor}
                        onChange={(e) => setFormData({...formData, accentColor: e.target.value})}
                        className="flex-1 px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-mono font-bold focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'invoice' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <FileText size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">Invoice Template</h3>
              </div>
              <div className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Invoice Number Prefix</label>
                    <input 
                      type="text" 
                      value={formData.invoicePrefix}
                      onChange={(e) => setFormData({...formData, invoicePrefix: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                      placeholder="e.g., INV-"
                    />
                  </div>
                  <div className="space-y-3">
                    <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Currency Symbol</label>
                    <input 
                      type="text" 
                      value={formData.currency}
                      onChange={(e) => setFormData({...formData, currency: e.target.value})}
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                      placeholder="e.g., Rs"
                    />
                  </div>
                </div>
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Invoice Footer Note</label>
                  <textarea 
                    value={formData.invoiceFooter}
                    onChange={(e) => setFormData({...formData, invoiceFooter: e.target.value})}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all h-32 resize-none"
                    placeholder="e.g., Thank you for your business!"
                  />
                </div>
              </div>
            </div>
          )}

          {activeTab === 'system' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
                <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-orange-600">
                  <SettingsIcon size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">System Configuration</h3>
              </div>
              <div className="space-y-8">
                <div className="space-y-3">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Low Stock Alert Threshold</label>
                  <input 
                    type="number" 
                    value={formData.lowStockThreshold}
                    onChange={(e) => setFormData({...formData, lowStockThreshold: parseInt(e.target.value)})}
                    className="w-full max-w-xs px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-sm text-slate-900 font-medium focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Products with stock below this number will trigger a dashboard alert</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-8 animate-in slide-in-from-right-4 duration-300">
              <div className="flex items-center gap-3 border-b border-slate-100 pb-6">
                <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-red-600">
                  <Shield size={20} />
                </div>
                <h3 className="text-xl font-bold text-slate-900 tracking-tight">Security & Access</h3>
              </div>
              <div className="p-20 text-center border-2 border-dashed border-slate-100 rounded-3xl">
                <div className="w-20 h-20 rounded-full bg-slate-50 flex items-center justify-center mx-auto mb-6">
                  <Shield className="text-slate-200" size={40} />
                </div>
                <p className="text-slate-400 font-bold uppercase tracking-widest text-xs">User role management and advanced security settings are coming soon</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

const SettingsNavButton: React.FC<{ active: boolean, onClick: () => void, icon: React.ReactNode, label: string }> = ({ active, onClick, icon, label }) => (
  <button 
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-sm uppercase tracking-widest transition-all",
      active 
        ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20" 
        : "text-slate-400 hover:bg-slate-50 hover:text-slate-600"
    )}
  >
    {icon}
    {label}
  </button>
);

export default Settings;
