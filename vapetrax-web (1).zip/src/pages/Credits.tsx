import React, { useState, useMemo } from 'react';
import { 
  CreditCard, 
  Search, 
  Plus, 
  Filter, 
  Trash2, 
  ArrowUpRight, 
  ArrowDownRight, 
  User, 
  Factory, 
  MoreHorizontal,
  X,
  Calendar
} from 'lucide-react';
import { useFirestore } from '../hooks/useFirestore';
import { formatCurrency, cn } from '../lib/utils';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { deleteDoc, doc, updateDoc, addDoc, collection, serverTimestamp, increment, orderBy, where } from 'firebase/firestore';
import { db } from '../firebase';
import toast from 'react-hot-toast';
import { useAuth } from '../contexts/AuthContext';

const Credits: React.FC = () => {
  const { shopId, currentUser } = useAuth();
  const { documents: credits, loading: creditsLoading } = useFirestore<any>(
    'credits', 
    where('shopId', '==', shopId),
    orderBy('createdAt', 'desc')
  );
  const { documents: customers } = useFirestore<any>('customers', where('shopId', '==', shopId));
  const { documents: suppliers } = useFirestore<any>('suppliers', where('shopId', '==', shopId));
  const { documents: sales } = useFirestore<any>(
    'sales', 
    where('shopId', '==', shopId),
    where('paymentMethod', '==', 'credit')
  );
  
  const [searchTerm, setSearchTerm] = useState('');
  const [typeFilter, setTypeFilter] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);

  // Combine manual credits and credit sales
  const combinedCredits = useMemo(() => {
    const manual = credits.map(c => ({
      ...c,
      source: 'manual',
      date: c.createdAt?.toDate ? c.createdAt.toDate() : new Date(c.createdAt)
    }));

    const saleCredits = sales.map(s => {
      const customer = customers.find(c => c.id === s.customerId);
      return {
        id: s.id,
        creditType: 'customer',
        customerId: s.customerId,
        entityName: customer?.name || 'Walk-in',
        amount: s.totalAmount,
        description: `Sale #${s.id?.slice(-6).toUpperCase()}`,
        transactionType: 'given',
        source: 'sale',
        date: s.saleDate?.toDate ? s.saleDate.toDate() : new Date(s.saleDate)
      };
    });

    let result = [...manual, ...saleCredits].sort((a, b) => b.date - a.date);

    return result.filter(c => {
      const name = c.entityName || customers.find(cust => cust.id === c.customerId)?.name || suppliers.find(s => s.id === c.supplierId)?.name || '';
      return (
        (name.toLowerCase().includes(searchTerm.toLowerCase()) || 
         c.description?.toLowerCase().includes(searchTerm.toLowerCase())) &&
        (typeFilter === 'all' || c.creditType === typeFilter)
      );
    });
  }, [credits, sales, customers, suppliers, searchTerm, typeFilter]);

  const handleDelete = async (credit: any) => {
    if (credit.source === 'sale') {
      toast.error('Credit sales must be deleted from Sales History');
      return;
    }

    if (window.confirm('Are you sure you want to delete this credit transaction?')) {
      try {
        // Reverse customer balance if applicable
        if (credit.creditType === 'customer' && credit.customerId) {
          const customerRef = doc(db, 'customers', credit.customerId);
          await updateDoc(customerRef, {
            creditBalance: increment(credit.transactionType === 'given' ? -credit.amount : credit.amount)
          });
        }

        await deleteDoc(doc(db, 'credits', credit.id));
        toast.success('Credit transaction deleted');
      } catch (error) {
        toast.error('Failed to delete transaction');
      }
    }
  };

  if (creditsLoading) return <LoadingSpinner />;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
            <CreditCard size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Credit Management</h1>
            <p className="text-slate-500 text-sm">Track manual credits, debts, and credit-based sales.</p>
          </div>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-violet-600/20 uppercase tracking-wider text-sm"
        >
          <Plus size={20} />
          Add Credit
        </button>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Total Credit Given</p>
          <p className="text-3xl font-bold text-amber-600">
            {formatCurrency(combinedCredits.filter(c => c.transactionType === 'given').reduce((acc, c) => acc + c.amount, 0))}
          </p>
        </div>
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Total Credit Taken</p>
          <p className="text-3xl font-bold text-emerald-600">
            {formatCurrency(combinedCredits.filter(c => c.transactionType === 'taken').reduce((acc, c) => acc + c.amount, 0))}
          </p>
        </div>
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Net Credit Balance</p>
          <p className="text-3xl font-bold text-slate-900">
            {formatCurrency(
              combinedCredits.filter(c => c.transactionType === 'given').reduce((acc, c) => acc + c.amount, 0) -
              combinedCredits.filter(c => c.transactionType === 'taken').reduce((acc, c) => acc + c.amount, 0)
            )}
          </p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="glass-card p-4 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name or description..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
          >
            <option value="all">All Types</option>
            <option value="customer">Customers</option>
            <option value="supplier">Suppliers</option>
            <option value="others">Others</option>
          </select>
          <button className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-400 hover:text-slate-600 transition-all shadow-sm">
            <Calendar size={20} />
          </button>
        </div>
      </div>

      {/* Credits Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Entity</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Type</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Amount</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Description</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {combinedCredits.map((credit) => {
                const customer = customers.find(c => c.id === credit.customerId);
                const supplier = suppliers.find(s => s.id === credit.supplierId);
                const entityName = credit.entityName || customer?.name || supplier?.name || 'Unknown';

                return (
                  <tr key={credit.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className={cn(
                          "w-10 h-10 rounded-xl flex items-center justify-center shadow-sm",
                          credit.creditType === 'customer' ? "bg-violet-100 text-violet-600" :
                          credit.creditType === 'supplier' ? "bg-blue-100 text-blue-600" :
                          "bg-slate-100 text-slate-600"
                        )}>
                          {credit.creditType === 'customer' ? <User size={18} /> : 
                           credit.creditType === 'supplier' ? <Factory size={18} /> : 
                           <MoreHorizontal size={18} />}
                        </div>
                        <span className="text-slate-900 font-bold">{entityName}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className={cn(
                        "inline-flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                        credit.transactionType === 'given' ? "bg-amber-100 text-amber-600" : "bg-emerald-100 text-emerald-600"
                      )}>
                        {credit.transactionType === 'given' ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}
                        {credit.transactionType}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-slate-900">{formatCurrency(credit.amount)}</td>
                    <td className="px-6 py-4">
                      <div className="flex flex-col">
                        <span className="text-sm text-slate-600">{credit.description}</span>
                        {credit.source === 'sale' && (
                          <span className="text-[10px] text-violet-600 font-bold uppercase tracking-widest mt-0.5">Sale Record</span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      {credit.date.toLocaleDateString()}
                    </td>
                    <td className="px-6 py-4 text-right">
                      {credit.source === 'manual' && (
                        <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => handleDelete(credit)}
                            className="p-2 hover:bg-rose-50 rounded-lg text-slate-400 hover:text-rose-600 transition-all" 
                            title="Delete"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {combinedCredits.length === 0 && (
          <div className="py-20 text-center">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <CreditCard className="text-slate-300" size={40} />
            </div>
            <p className="text-slate-400 font-medium">No credit transactions found.</p>
          </div>
        )}
      </div>

      {/* Add Credit Modal */}
      {showAddModal && (
        <AddCreditModal 
          customers={customers} 
          suppliers={suppliers} 
          onClose={() => setShowAddModal(false)} 
        />
      )}
    </div>
  );
};

const AddCreditModal: React.FC<{ customers: any[], suppliers: any[], onClose: () => void }> = ({ customers, suppliers, onClose }) => {
  const { shopId, currentUser } = useAuth();
  const [formData, setFormData] = useState({
    creditType: 'customer',
    customerId: '',
    supplierId: '',
    entityName: '',
    entityContact: '',
    amount: 0,
    description: '',
    transactionType: 'given'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'credits'), {
        ...formData,
        shopId,
        createdBy: currentUser?.uid,
        createdAt: serverTimestamp()
      });

      // Update customer balance if applicable
      if (formData.creditType === 'customer' && formData.customerId) {
        const customerRef = doc(db, 'customers', formData.customerId);
        await updateDoc(customerRef, {
          creditBalance: increment(formData.transactionType === 'given' ? formData.amount : -formData.amount)
        });
      }

      toast.success('Credit transaction added successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to add transaction');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl animate-in zoom-in duration-300 overflow-hidden border border-slate-200">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900">Add Credit Transaction</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-xl text-slate-400 transition-colors"><X size={20} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Credit Type</label>
            <select 
              value={formData.creditType}
              onChange={(e) => setFormData({...formData, creditType: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
            >
              <option value="customer">Customer</option>
              <option value="supplier">Supplier</option>
              <option value="others">Others</option>
            </select>
          </div>

          {formData.creditType === 'customer' && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Select Customer</label>
              <select 
                required
                value={formData.customerId}
                onChange={(e) => setFormData({...formData, customerId: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              >
                <option value="">Choose a customer...</option>
                {customers.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
            </div>
          )}

          {formData.creditType === 'supplier' && (
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Select Supplier</label>
              <select 
                required
                value={formData.supplierId}
                onChange={(e) => setFormData({...formData, supplierId: e.target.value})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              >
                <option value="">Choose a supplier...</option>
                {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          )}

          {formData.creditType === 'others' && (
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Entity Name</label>
                <input 
                  required
                  type="text" 
                  value={formData.entityName}
                  onChange={(e) => setFormData({...formData, entityName: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Contact</label>
                <input 
                  type="text" 
                  value={formData.entityContact}
                  onChange={(e) => setFormData({...formData, entityContact: e.target.value})}
                  className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Amount (Rs)</label>
              <input 
                required
                type="number" 
                value={formData.amount}
                onChange={(e) => setFormData({...formData, amount: parseFloat(e.target.value)})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Transaction Type</label>
              <select 
                value={formData.transactionType}
                onChange={(e) => setFormData({...formData, transactionType: e.target.value as any})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              >
                <option value="given">Given (Credit)</option>
                <option value="taken">Taken (Debt)</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Description</label>
            <textarea 
              value={formData.description}
              onChange={(e) => setFormData({...formData, description: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all h-24 resize-none"
              placeholder="Reason for credit..."
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-4 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-2xl transition-all uppercase tracking-wider text-sm"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 py-4 px-4 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-2xl shadow-lg shadow-violet-600/20 transition-all active:scale-[0.98] uppercase tracking-wider text-sm"
            >
              Save
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Credits;
