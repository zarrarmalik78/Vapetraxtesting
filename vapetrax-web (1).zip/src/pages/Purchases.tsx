import React, { useState, useMemo } from 'react';
import { 
  Download, 
  Search, 
  Plus, 
  Filter, 
  Trash2, 
  Calendar, 
  Factory, 
  Package, 
  ArrowUpDown,
  X,
  Clock
} from 'lucide-react';
import { useFirestore } from '../hooks/useFirestore';
import { formatCurrency, cn } from '../lib/utils';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { deleteDoc, doc, updateDoc, addDoc, collection, serverTimestamp, increment, orderBy, getDoc, where } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const Purchases: React.FC = () => {
  const { shopId } = useAuth();
  const { documents: purchases, loading } = useFirestore<any>(
    'purchases', 
    where('shopId', '==', shopId),
    orderBy('purchaseDate', 'desc')
  );
  const { documents: suppliers } = useFirestore<any>('suppliers', where('shopId', '==', shopId));
  const { documents: products } = useFirestore<any>('products', where('shopId', '==', shopId));
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredPurchases = useMemo(() => {
    return purchases.filter(p => {
      const supplier = suppliers.find(s => s.id === p.supplierId);
      const product = products.find(prod => prod.id === p.productId);
      return (
        (supplier?.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
         product?.name?.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    });
  }, [purchases, suppliers, products, searchTerm]);

  const handleDelete = async (purchase: any) => {
    if (window.confirm('Are you sure you want to delete this purchase? This will deduct the stock from the product.')) {
      try {
        const productRef = doc(db, 'products', purchase.productId);
        await updateDoc(productRef, {
          stockQuantity: increment(-purchase.quantity)
        });

        // Log the removal
        await addDoc(collection(db, 'inventoryLogs'), {
          productId: purchase.productId,
          action: 'adjustment',
          quantityChange: -purchase.quantity,
          notes: `Purchase Deleted: ${purchase.id}`,
          shopId,
          createdAt: serverTimestamp()
        });

        await deleteDoc(doc(db, 'purchases', purchase.id));
        toast.success('Purchase deleted and stock adjusted');
      } catch (error) {
        toast.error('Failed to delete purchase');
      }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
            <Package size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Purchase Management</h1>
            <p className="text-slate-500 text-sm">Track and manage your inventory procurement from suppliers</p>
          </div>
        </div>
        <button 
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-6 py-3 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-violet-600/20 uppercase tracking-wider text-sm"
        >
          <Plus size={20} />
          Add Purchase
        </button>
      </header>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Total Purchases</p>
          <p className="text-3xl font-bold text-slate-900">{purchases.length}</p>
        </div>
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Total Procurement Cost</p>
          <p className="text-3xl font-bold text-violet-600">
            {formatCurrency(purchases.reduce((acc, p) => acc + (p.purchasePrice * p.quantity), 0))}
          </p>
        </div>
        <div className="glass-card p-6">
          <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">Items Procured</p>
          <p className="text-3xl font-bold text-emerald-600">
            {purchases.reduce((acc, p) => acc + p.quantity, 0)}
          </p>
        </div>
      </div>

      {/* Search */}
      <div className="glass-card p-4">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by supplier or product name..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
          />
        </div>
      </div>

      {/* Purchases Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 border-b border-slate-100">
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Product</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Supplier</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Qty</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cost</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Date</th>
                <th className="px-6 py-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredPurchases.map((purchase) => {
                const supplier = suppliers.find(s => s.id === purchase.supplierId);
                const product = products.find(p => p.id === purchase.productId);
                return (
                  <tr key={purchase.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Package size={14} className="text-slate-400" />
                        <span className="text-slate-900 font-bold">{product?.name || 'Unknown Product'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Factory size={14} className="text-slate-400" />
                        <span className="text-slate-600 text-sm">{supplier?.name || 'Unknown Supplier'}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-900 font-bold">{purchase.quantity}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">{formatCurrency(purchase.purchasePrice)}</td>
                    <td className="px-6 py-4 text-sm text-violet-600 font-bold">{formatCurrency(purchase.purchasePrice * purchase.quantity)}</td>
                    <td className="px-6 py-4 text-sm text-slate-500">
                      <div className="flex items-center gap-1">
                        <Clock size={14} className="text-slate-400" />
                        {purchase.purchaseDate?.toDate ? purchase.purchaseDate.toDate().toLocaleDateString() : new Date(purchase.purchaseDate).toLocaleDateString()}
                      </div>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => handleDelete(purchase)}
                          className="p-2 hover:bg-red-50 rounded-lg text-slate-400 hover:text-red-600 transition-all" 
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filteredPurchases.length === 0 && (
          <div className="py-20 text-center">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package className="text-slate-300" size={40} />
            </div>
            <p className="text-slate-400 font-medium">No purchases found matching your search.</p>
          </div>
        )}
      </div>

      {/* Add Purchase Modal */}
      {showAddModal && (
        <AddPurchaseModal 
          suppliers={suppliers} 
          products={products}
          onClose={() => setShowAddModal(false)} 
        />
      )}
    </div>
  );
};

const AddPurchaseModal: React.FC<{ suppliers: any[], products: any[], onClose: () => void }> = ({ suppliers, products, onClose }) => {
  const { shopId } = useAuth();
  const [formData, setFormData] = useState({
    supplierId: '',
    productId: '',
    quantity: 0,
    purchasePrice: 0,
    purchaseDate: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const purchaseData = {
        ...formData,
        shopId,
        purchaseDate: new Date(formData.purchaseDate),
        createdAt: serverTimestamp()
      };
      
      await addDoc(collection(db, 'purchases'), purchaseData);
      
      // Update product stock
      const productRef = doc(db, 'products', formData.productId);
      await updateDoc(productRef, {
        stockQuantity: increment(formData.quantity),
        costPrice: formData.purchasePrice, // Update cost price to latest
        updatedAt: serverTimestamp()
      });

      // If e-liquid, create bottles
      const product = products.find(p => p.id === formData.productId);
      if (product?.category === 'e-liquid') {
        const bottleSizeNum = parseInt(product.bottleSize) || 30;
        for (let i = 0; i < formData.quantity; i++) {
          await addDoc(collection(db, `products/${formData.productId}/bottles`), {
            bottleSize: bottleSizeNum,
            remainingMl: bottleSizeNum,
            status: 'closed',
            shopId,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }
      }

      // Log the addition
      await addDoc(collection(db, 'inventoryLogs'), {
        productId: formData.productId,
        action: 'purchase',
        quantityChange: formData.quantity,
        notes: `New Purchase from ${suppliers.find(s => s.id === formData.supplierId)?.name}`,
        shopId,
        createdAt: serverTimestamp()
      });

      toast.success('Purchase recorded successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to record purchase');
    }
  };

  return (
    <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl animate-in zoom-in duration-300 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <h2 className="text-xl font-bold text-slate-900">Record New Purchase</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-xl text-slate-400 transition-colors">
            <X size={20} />
          </button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Supplier</label>
            <select 
              required
              value={formData.supplierId}
              onChange={(e) => setFormData({...formData, supplierId: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
            >
              <option value="">Choose a supplier...</option>
              {suppliers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Product</label>
            <select 
              required
              value={formData.productId}
              onChange={(e) => setFormData({...formData, productId: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
            >
              <option value="">Choose a product...</option>
              {products.map(p => <option key={p.id} value={p.id}>{p.name} ({p.brand})</option>)}
            </select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Quantity</label>
              <input 
                required
                type="number" 
                value={formData.quantity}
                onChange={(e) => setFormData({...formData, quantity: parseInt(e.target.value)})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Cost Price (Rs)</label>
              <input 
                required
                type="number" 
                value={formData.purchasePrice}
                onChange={(e) => setFormData({...formData, purchasePrice: parseFloat(e.target.value)})}
                className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
              />
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-widest ml-1">Purchase Date</label>
            <input 
              required
              type="date" 
              value={formData.purchaseDate}
              onChange={(e) => setFormData({...formData, purchaseDate: e.target.value})}
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-4 px-4 bg-slate-100 hover:bg-slate-200 text-slate-600 font-bold rounded-xl transition-all uppercase tracking-widest text-xs"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 py-4 px-4 bg-violet-600 hover:bg-violet-700 text-white font-bold rounded-xl shadow-lg shadow-violet-600/20 transition-all uppercase tracking-widest text-xs"
            >
              Record Purchase
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Purchases;
