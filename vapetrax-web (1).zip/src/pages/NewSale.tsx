import React, { useState, useMemo, useEffect } from 'react';
import { 
  Search, 
  ShoppingCart, 
  Trash2, 
  Plus, 
  Minus, 
  UserPlus, 
  CreditCard, 
  Banknote, 
  RefreshCw,
  X,
  CheckCircle2,
  AlertCircle,
  Droplet,
  Droplets,
  Package
} from 'lucide-react';
import { useFirestore } from '../hooks/useFirestore';
import { formatCurrency, cn } from '../lib/utils';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { 
  collection, 
  addDoc, 
  serverTimestamp, 
  doc, 
  updateDoc, 
  getDocs, 
  query, 
  where, 
  orderBy, 
  limit,
  increment,
  writeBatch,
  getDoc
} from 'firebase/firestore';
import { db } from '../firebase';
import toast from 'react-hot-toast';
import { useAuth } from '../contexts/AuthContext';

interface CartItem {
  productId: string;
  productName: string;
  brand: string;
  category: string;
  unitPrice: number;
  quantity: number;
  saleType: 'regular' | 'refill' | 'full_bottle';
  refillAmount?: number;
  bottleSize?: number;
}

const NewSale: React.FC = () => {
  const { currentUser, shopId } = useAuth();
  const { documents: products, loading: productsLoading } = useFirestore<any>(
    'products',
    where('shopId', '==', shopId)
  );
  const { documents: customers, loading: customersLoading } = useFirestore<any>(
    'customers',
    where('shopId', '==', shopId)
  );
  
  const [searchTerm, setSearchTerm] = useState('');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'online' | 'credit' | 'return'>('cash');
  const [isProcessing, setIsProcessing] = useState(false);
  const [showRefillModal, setShowRefillModal] = useState<{ product: any } | null>(null);
  const [refillAmount, setRefillAmount] = useState<number>(1.0);

  const filteredProducts = useMemo(() => {
    if (!searchTerm) return [];
    return products.filter(p => 
      p.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
      p.brand?.toLowerCase().includes(searchTerm.toLowerCase())
    ).slice(0, 10);
  }, [products, searchTerm]);

  const addToCart = (product: any, type: 'regular' | 'refill' | 'full_bottle', amount?: number) => {
    const existingItemIndex = cart.findIndex(item => 
      item.productId === product.id && item.saleType === type && item.refillAmount === amount
    );

    if (existingItemIndex > -1) {
      const newCart = [...cart];
      newCart[existingItemIndex].quantity += 1;
      setCart(newCart);
    } else {
      setCart([...cart, {
        productId: product.id,
        productName: product.name,
        brand: product.brand,
        category: product.category,
        unitPrice: type === 'refill' ? (product.sellingPrice / (parseInt(product.bottleSize) || 30)) * (amount || 1) : product.sellingPrice,
        quantity: 1,
        saleType: type,
        refillAmount: amount,
        bottleSize: parseInt(product.bottleSize) || 30
      }]);
    }
    setSearchTerm('');
    toast.success(`${product.name} added to cart`);
  };

  const removeFromCart = (index: number) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  const updateQuantity = (index: number, delta: number) => {
    const newCart = [...cart];
    newCart[index].quantity = Math.max(1, newCart[index].quantity + delta);
    setCart(newCart);
  };

  const totalAmount = cart.reduce((acc, item) => acc + (item.unitPrice * item.quantity), 0);

  const handleCompleteSale = async () => {
    if (cart.length === 0) {
      toast.error('Cart is empty');
      return;
    }

    if (paymentMethod === 'credit' && !selectedCustomerId) {
      toast.error('Customer must be selected for credit sales');
      return;
    }

    setIsProcessing(true);
    const batch = writeBatch(db);

    try {
      const saleItems = [];
      
      for (const item of cart) {
        const productRef = doc(db, 'products', item.productId);
        
        if (item.saleType === 'refill') {
          // Smart Bottle System for Refills
          let remainingRefill = (item.refillAmount || 0) * item.quantity;
          
          // 1. Get opened bottles first
          const openedBottlesQuery = query(
            collection(db, `products/${item.productId}/bottles`),
            where('shopId', '==', shopId),
            where('status', '==', 'opened'),
            orderBy('openedDate', 'asc')
          );
          const openedSnapshot = await getDocs(openedBottlesQuery);
          
          for (const bottleDoc of openedSnapshot.docs) {
            if (remainingRefill <= 0) break;
            const bottleData = bottleDoc.data();
            const deduction = Math.min(bottleData.remainingMl, remainingRefill);
            const newRemaining = bottleData.remainingMl - deduction;
            
            batch.update(bottleDoc.ref, {
              remainingMl: newRemaining,
              status: newRemaining <= 0 ? 'empty' : 'opened',
              updatedAt: serverTimestamp()
            });
            
            remainingRefill -= deduction;
          }
          
          // 2. If still need more, open closed bottles
          if (remainingRefill > 0) {
            const closedBottlesQuery = query(
              collection(db, `products/${item.productId}/bottles`),
              where('shopId', '==', shopId),
              where('status', '==', 'closed'),
              orderBy('createdAt', 'asc')
            );
            const closedSnapshot = await getDocs(closedBottlesQuery);
            
            for (const bottleDoc of closedSnapshot.docs) {
              if (remainingRefill <= 0) break;
              const bottleData = bottleDoc.data();
              const deduction = Math.min(bottleData.remainingMl, remainingRefill);
              const newRemaining = bottleData.remainingMl - deduction;
              
              batch.update(bottleDoc.ref, {
                remainingMl: newRemaining,
                status: newRemaining <= 0 ? 'empty' : 'opened',
                openedDate: serverTimestamp(),
                updatedAt: serverTimestamp()
              });
              
              remainingRefill -= deduction;
            }
          }

          // Update total stock quantity (ML)
          batch.update(productRef, {
            stockQuantity: increment(-((item.refillAmount || 0) * item.quantity))
          });

        } else if (item.saleType === 'full_bottle') {
          // Sell a full closed bottle
          const closedBottlesQuery = query(
            collection(db, `products/${item.productId}/bottles`),
            where('shopId', '==', shopId),
            where('status', '==', 'closed'),
            orderBy('createdAt', 'asc'),
            limit(item.quantity)
          );
          const closedSnapshot = await getDocs(closedBottlesQuery);
          
          if (closedSnapshot.docs.length < item.quantity) {
            throw new Error(`Not enough full bottles for ${item.productName}`);
          }

          closedSnapshot.docs.forEach(bottleDoc => {
            batch.update(bottleDoc.ref, {
              status: 'sold',
              updatedAt: serverTimestamp()
            });
          });

          batch.update(productRef, {
            stockQuantity: increment(-item.quantity)
          });
        } else {
          // Regular product
          batch.update(productRef, {
            stockQuantity: increment(-item.quantity)
          });
        }

        saleItems.push({
          productId: item.productId,
          productName: item.productName,
          quantity: item.quantity,
          unitPrice: item.unitPrice,
          totalPrice: item.unitPrice * item.quantity,
          saleType: item.saleType,
          refillAmount: item.refillAmount || null
        });

        // Create Inventory Log
        const logRef = doc(collection(db, 'inventoryLogs'));
        batch.set(logRef, {
          productId: item.productId,
          shopId,
          action: 'sale',
          quantityChange: -item.quantity,
          notes: `Sale: ${item.saleType}`,
          createdAt: serverTimestamp()
        });
      }

      // Create Sale Record
      const saleRef = doc(collection(db, 'sales'));
      batch.set(saleRef, {
        customerId: selectedCustomerId,
        shopId,
        totalAmount,
        paymentMethod,
        saleDate: serverTimestamp(),
        items: saleItems,
        createdBy: currentUser?.uid
      });

      // Update Customer Credit if applicable
      if (paymentMethod === 'credit' && selectedCustomerId) {
        const customerRef = doc(db, 'customers', selectedCustomerId);
        batch.update(customerRef, {
          creditBalance: increment(totalAmount)
        });
      }

      await batch.commit();
      toast.success('Sale completed successfully!');
      setCart([]);
      setSelectedCustomerId(null);
      setPaymentMethod('cash');
    } catch (error: any) {
      console.error(error);
      toast.error(error.message || 'Failed to complete sale');
    } finally {
      setIsProcessing(false);
    }
  };

  if (productsLoading || customersLoading) return <LoadingSpinner />;

  return (
    <div className="h-[calc(100vh-120px)] flex flex-col lg:flex-row gap-8 animate-in fade-in duration-500 pb-12">
      {/* Left Panel: Product Selection */}
      <div className="flex-1 flex flex-col gap-6 min-w-0">
        <div className="glass-card p-6">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
              <Search size={24} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">New Sale</h1>
              <p className="text-slate-500 text-sm">Search and add products to the current order</p>
            </div>
          </div>
          
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Search by name, brand, or scan barcode..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl text-slate-900 text-lg placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all shadow-sm"
            />
          </div>

          {/* Search Results */}
          {searchTerm && (
            <div className="mt-4 space-y-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {filteredProducts.map((product) => (
                <div key={product.id} className="p-4 bg-white border border-slate-100 rounded-xl hover:bg-slate-50 hover:border-violet-200 transition-all flex items-center justify-between group shadow-sm">
                  <div className="flex items-center gap-4">
                    <div className={cn(
                      "w-12 h-12 rounded-xl flex items-center justify-center",
                      product.category === 'device' ? "bg-blue-100 text-blue-600" :
                      product.category === 'coil' ? "bg-emerald-100 text-emerald-600" :
                      "bg-fuchsia-100 text-fuchsia-600"
                    )}>
                      {product.category === 'e-liquid' ? <Droplet size={24} /> : <Package size={24} />}
                    </div>
                    <div>
                      <p className="text-slate-900 font-bold">{product.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{product.brand} • {formatCurrency(product.sellingPrice)}</p>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {product.category === 'e-liquid' ? (
                      <>
                        <button 
                          onClick={() => setShowRefillModal({ product })}
                          className="px-4 py-2 bg-violet-50 text-violet-600 hover:bg-violet-600 hover:text-white rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all border border-violet-100"
                        >
                          Refill
                        </button>
                        <button 
                          onClick={() => addToCart(product, 'full_bottle')}
                          className="px-4 py-2 bg-fuchsia-50 text-fuchsia-600 hover:bg-fuchsia-600 hover:text-white rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all border border-fuchsia-100"
                        >
                          Full Bottle
                        </button>
                      </>
                    ) : (
                      <button 
                        onClick={() => addToCart(product, 'regular')}
                        className="p-2.5 bg-violet-600 text-white rounded-lg hover:bg-violet-700 transition-all shadow-md shadow-violet-600/20"
                      >
                        <Plus size={20} />
                      </button>
                    )}
                  </div>
                </div>
              ))}
              {filteredProducts.length === 0 && (
                <div className="text-center py-12 text-slate-400 font-medium">No products found</div>
              )}
            </div>
          )}
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-6">
          <div className="metric-card-violet rounded-2xl p-6 shadow-lg shadow-violet-500/20">
            <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Items in Cart</p>
            <p className="text-3xl font-bold">{cart.reduce((acc, i) => acc + i.quantity, 0)}</p>
          </div>
          <div className="metric-card-emerald rounded-2xl p-6 shadow-lg shadow-emerald-500/20">
            <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Total Amount</p>
            <p className="text-3xl font-bold">{formatCurrency(totalAmount)}</p>
          </div>
        </div>
      </div>

      {/* Right Panel: Cart & Checkout */}
      <div className="w-full lg:w-[450px] flex flex-col gap-6">
        <div className="flex-1 glass-card flex flex-col overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <ShoppingCart className="text-violet-600" size={22} />
              Current Order
            </h2>
            <button 
              onClick={() => setCart([])}
              className="text-[10px] font-bold text-slate-400 hover:text-rose-600 uppercase tracking-widest transition-colors"
            >
              Clear All
            </button>
          </div>

          {/* Cart Items */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
            {cart.length > 0 ? (
              cart.map((item, index) => (
                <div key={index} className="p-4 bg-white border border-slate-100 rounded-xl group animate-in slide-in-from-right duration-300 shadow-sm">
                  <div className="flex justify-between items-start mb-3">
                    <div className="min-w-0">
                      <p className="text-slate-900 font-bold truncate">{item.productName}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        {item.saleType.replace('_', ' ')} {item.refillAmount ? `(${item.refillAmount}ml)` : ''}
                      </p>
                    </div>
                    <button 
                      onClick={() => removeFromCart(index)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                    >
                      <Trash2 size={16} />
                    </button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3 bg-slate-100 rounded-xl p-1">
                      <button 
                        onClick={() => updateQuantity(index, -1)}
                        className="p-1.5 hover:bg-white rounded-lg text-slate-600 transition-all shadow-sm"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="text-slate-900 font-bold min-w-[24px] text-center">{item.quantity}</span>
                      <button 
                        onClick={() => updateQuantity(index, 1)}
                        className="p-1.5 hover:bg-white rounded-lg text-slate-600 transition-all shadow-sm"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                    <p className="text-violet-600 font-bold text-lg">{formatCurrency(item.unitPrice * item.quantity)}</p>
                  </div>
                </div>
              ))
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-300">
                <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4">
                  <ShoppingCart size={40} />
                </div>
                <p className="font-medium">Your cart is empty</p>
              </div>
            )}
          </div>

          {/* Checkout Section */}
          <div className="p-6 bg-slate-50/50 border-t border-slate-100 space-y-6">
            {/* Customer Selection */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Customer</label>
                <button className="text-[10px] font-bold text-violet-600 hover:text-violet-700 flex items-center gap-1 uppercase tracking-widest">
                  <UserPlus size={12} />
                  Quick Add
                </button>
              </div>
              <select 
                value={selectedCustomerId || ''}
                onChange={(e) => setSelectedCustomerId(e.target.value || null)}
                className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-slate-900 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-violet-500/20 shadow-sm"
              >
                <option value="">Walk-in Customer</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>{c.name} ({c.phone})</option>
                ))}
              </select>
            </div>

            {/* Payment Method */}
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">Payment Method</label>
              <div className="grid grid-cols-2 gap-3">
                {[
                  { id: 'cash', icon: Banknote, label: 'Cash' },
                  { id: 'online', icon: RefreshCw, label: 'Online' },
                  { id: 'credit', icon: CreditCard, label: 'Credit' },
                  { id: 'return', icon: Trash2, label: 'Return' },
                ].map((method) => (
                  <button
                    key={method.id}
                    onClick={() => setPaymentMethod(method.id as any)}
                    className={cn(
                      "flex items-center gap-2 px-4 py-3 rounded-xl border transition-all text-sm font-bold uppercase tracking-wider",
                      paymentMethod === method.id 
                        ? "bg-violet-600 border-violet-500 text-white shadow-lg shadow-violet-600/20" 
                        : "bg-white border-slate-200 text-slate-500 hover:bg-slate-50"
                    )}
                  >
                    <method.icon size={16} />
                    {method.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Total & Action */}
            <div className="pt-4 border-t border-slate-200">
              <div className="flex justify-between items-end mb-6">
                <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest">Total Amount</p>
                <p className="text-4xl font-bold text-slate-900 tracking-tight">{formatCurrency(totalAmount)}</p>
              </div>
              <button 
                onClick={handleCompleteSale}
                disabled={isProcessing || cart.length === 0}
                className="w-full py-4 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-2xl shadow-xl shadow-rose-500/20 transition-all active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3 text-lg"
              >
                {isProcessing ? (
                  <div className="w-6 h-6 border-3 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <CheckCircle2 size={24} />
                    Complete Sale
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Refill Modal */}
      {showRefillModal && (
        <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="glass-card w-full max-w-md shadow-2xl animate-in zoom-in duration-300 overflow-hidden">
            <div className="p-6 border-b border-slate-100 flex items-center justify-center relative">
              <h2 className="text-xl font-bold text-slate-900 tracking-tight">E-Liquid Refill</h2>
              <button onClick={() => setShowRefillModal(null)} className="absolute right-6 p-2 hover:bg-slate-50 rounded-xl text-slate-400 transition-colors"><X size={20} /></button>
            </div>
            <div className="p-8 space-y-8">
              <div className="text-center">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{showRefillModal.product.brand}</p>
                <h3 className="text-2xl font-bold text-slate-900 tracking-tight mb-4">{showRefillModal.product.name}</h3>
                <div className="inline-flex items-center gap-2 px-4 py-2 bg-violet-50 rounded-full text-violet-600 font-bold text-xs uppercase tracking-widest">
                  <Droplets size={14} />
                  {showRefillModal.product.stockQuantity}ml Available
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Refill Amount (ml)</label>
                <div className="grid grid-cols-4 gap-2">
                  {[1.0, 1.5, 2.0, 3.0, 5.0, 10.0, 15.0, 30.0].map((val) => (
                    <button
                      key={val}
                      onClick={() => setRefillAmount(val)}
                      className={cn(
                        "py-2 rounded-xl border text-[10px] font-bold uppercase tracking-widest transition-all",
                        refillAmount === val 
                          ? "bg-violet-600 border-violet-500 text-white shadow-md" 
                          : "bg-slate-50 border-slate-100 text-slate-400 hover:bg-slate-100"
                      )}
                    >
                      {val}ml
                    </button>
                  ))}
                </div>
                <div className="relative mt-4">
                  <input 
                    type="number" 
                    step="0.1"
                    value={refillAmount}
                    onChange={(e) => setRefillAmount(parseFloat(e.target.value))}
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-100 rounded-xl text-slate-900 text-center text-xl font-bold focus:ring-2 focus:ring-violet-500/20 focus:border-violet-500 outline-none transition-all"
                  />
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs uppercase tracking-widest">ml</div>
                </div>
              </div>

              <div className="p-6 bg-slate-50 rounded-2xl border border-slate-100 flex justify-between items-center">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Total Price</span>
                <span className="text-2xl font-bold text-violet-600">
                  {formatCurrency((showRefillModal.product.sellingPrice / (parseInt(showRefillModal.product.bottleSize) || 30)) * refillAmount)}
                </span>
              </div>

              <button 
                onClick={() => {
                  addToCart(showRefillModal.product, 'refill', refillAmount);
                  setShowRefillModal(null);
                }}
                className="w-full py-4 bg-violet-600 hover:bg-violet-700 text-white font-bold text-xs uppercase tracking-widest rounded-xl shadow-lg shadow-violet-600/20 transition-all active:scale-[0.98]"
              >
                Add Refill to Cart
              </button>
            </div>
            <div className="p-4 bg-slate-50/50 border-t border-slate-100 text-center">
              <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Inventory will be deducted automatically</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default NewSale;
