import React, { useState, useMemo } from 'react';
import { 
  Package, 
  Plus, 
  Search, 
  Filter, 
  MoreVertical, 
  Edit2, 
  Trash2, 
  Eye, 
  ArrowUpDown,
  Download,
  Upload,
  AlertCircle,
  ChevronDown,
  ChevronUp,
  X
} from 'lucide-react';
import { useFirestore } from '../hooks/useFirestore';
import { formatCurrency, cn } from '../lib/utils';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { deleteDoc, doc, updateDoc, addDoc, collection, serverTimestamp, orderBy, where } from 'firebase/firestore';
import { db } from '../firebase';
import { useAuth } from '../contexts/AuthContext';
import toast from 'react-hot-toast';

const Stock: React.FC = () => {
  const { shopId } = useAuth();
  const { documents: products, loading } = useFirestore<any>(
    'products', 
    where('shopId', '==', shopId),
    orderBy('createdAt', 'desc')
  );
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortConfig, setSortConfig] = useState<{ key: string, direction: 'asc' | 'desc' }>({ key: 'createdAt', direction: 'desc' });
  const [showAddModal, setShowAddModal] = useState(false);

  const filteredProducts = useMemo(() => {
    let result = products.filter(p => 
      (p.name?.toLowerCase().includes(searchTerm.toLowerCase()) || 
       p.brand?.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (categoryFilter === 'all' || p.category === categoryFilter)
    );

    if (sortConfig.key) {
      result.sort((a, b) => {
        const aValue = a[sortConfig.key];
        const bValue = b[sortConfig.key];
        if (aValue < bValue) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue > bValue) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return result;
  }, [products, searchTerm, categoryFilter, sortConfig]);

  const handleSort = (key: string) => {
    setSortConfig(prev => ({
      key,
      direction: prev.key === key && prev.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  const handleDelete = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this product?')) {
      try {
        await deleteDoc(doc(db, 'products', id));
        toast.success('Product deleted successfully');
      } catch (error) {
        toast.error('Failed to delete product');
      }
    }
  };

  if (loading) return <LoadingSpinner />;

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 glass-card p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
            <Package size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Inventory Management</h1>
            <p className="text-slate-500 text-sm">Manage your products, stock levels, and e-liquid bottles</p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <button 
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-rose-500 hover:bg-rose-600 text-white px-4 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-lg shadow-rose-500/20"
          >
            <Plus size={18} />
            Add Product
          </button>
          <button className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
            <Upload size={20} />
          </button>
          <button className="p-2.5 bg-white border border-slate-200 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-50 transition-all shadow-sm">
            <Download size={20} />
          </button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="metric-card-violet rounded-2xl p-6 shadow-lg shadow-violet-500/20">
          <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Total Products</p>
          <p className="text-3xl font-bold">{products.length}</p>
        </div>
        <div className="metric-card-orange rounded-2xl p-6 shadow-lg shadow-orange-500/20">
          <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Low Stock Items</p>
          <p className="text-3xl font-bold">{products.filter(p => p.stockQuantity <= p.minStockLevel).length}</p>
        </div>
        <div className="metric-card-red rounded-2xl p-6 shadow-lg shadow-rose-500/20">
          <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Out of Stock</p>
          <p className="text-3xl font-bold">{products.filter(p => p.stockQuantity === 0).length}</p>
        </div>
        <div className="metric-card-emerald rounded-2xl p-6 shadow-lg shadow-emerald-500/20">
          <p className="text-white/70 text-[10px] font-bold uppercase tracking-widest mb-1">Total Value</p>
          <p className="text-3xl font-bold">
            {formatCurrency(products.reduce((acc, p) => acc + (p.costPrice * p.stockQuantity), 0))}
          </p>
        </div>
      </div>

      {/* Filters & Search */}
      <div className="glass-card p-4 flex flex-col md:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search by name or brand..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
          />
        </div>
        <div className="flex gap-2">
          <select 
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-slate-700 font-medium focus:outline-none focus:ring-2 focus:ring-violet-500/20 transition-all"
          >
            <option value="all">All Categories</option>
            <option value="device">Devices</option>
            <option value="coil">Coils</option>
            <option value="e-liquid">E-Liquids</option>
          </select>
          <button className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-400 hover:text-slate-600 transition-all">
            <Filter size={20} />
          </button>
        </div>
      </div>

      {/* Product Table */}
      <div className="glass-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50/50 text-slate-500 text-[10px] uppercase tracking-widest">
                <th className="px-6 py-4 font-bold cursor-pointer hover:text-violet-600 transition-colors" onClick={() => handleSort('name')}>
                  <div className="flex items-center gap-2">Product <ArrowUpDown size={12} /></div>
                </th>
                <th className="px-6 py-4 font-bold">Category</th>
                <th className="px-6 py-4 font-bold cursor-pointer hover:text-violet-600 transition-colors" onClick={() => handleSort('costPrice')}>
                  <div className="flex items-center gap-2">Cost <ArrowUpDown size={12} /></div>
                </th>
                <th className="px-6 py-4 font-bold cursor-pointer hover:text-violet-600 transition-colors" onClick={() => handleSort('sellingPrice')}>
                  <div className="flex items-center gap-2">Selling <ArrowUpDown size={12} /></div>
                </th>
                <th className="px-6 py-4 font-bold cursor-pointer hover:text-violet-600 transition-colors" onClick={() => handleSort('stockQuantity')}>
                  <div className="flex items-center gap-2">Stock <ArrowUpDown size={12} /></div>
                </th>
                <th className="px-6 py-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredProducts.map((product) => (
                <tr key={product.id} className="hover:bg-slate-50/50 transition-colors group">
                  <td className="px-6 py-4">
                    <div>
                      <p className="text-slate-900 font-semibold group-hover:text-violet-600 transition-colors">{product.name}</p>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{product.brand}</p>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider",
                      product.category === 'device' ? "bg-blue-100 text-blue-700" :
                      product.category === 'coil' ? "bg-emerald-100 text-emerald-700" :
                      "bg-fuchsia-100 text-fuchsia-700"
                    )}>
                      {product.category}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500 font-medium">{formatCurrency(product.costPrice)}</td>
                  <td className="px-6 py-4 text-sm text-slate-900 font-bold">{formatCurrency(product.sellingPrice)}</td>
                  <td className="px-6 py-4">
                    <div className="flex flex-col">
                      <span className={cn(
                        "font-bold text-sm",
                        product.stockQuantity <= product.minStockLevel ? "text-amber-600" : "text-slate-900"
                      )}>
                        {product.stockQuantity} {product.unit || 'units'}
                      </span>
                      {product.category === 'e-liquid' && (
                        <span className="text-[10px] font-bold text-slate-400 uppercase">
                          {product.bottleSize} bottles
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex items-center justify-end gap-1 opacity-0 group-hover:opacity-100 transition-all">
                      <button className="p-2 hover:bg-violet-50 rounded-lg text-slate-400 hover:text-violet-600 transition-all" title="View Details">
                        <Eye size={18} />
                      </button>
                      <button className="p-2 hover:bg-violet-50 rounded-lg text-slate-400 hover:text-violet-600 transition-all" title="Edit">
                        <Edit2 size={18} />
                      </button>
                      <button 
                        onClick={() => handleDelete(product.id)}
                        className="p-2 hover:bg-rose-50 rounded-lg text-slate-400 hover:text-rose-600 transition-all" 
                        title="Delete"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {filteredProducts.length === 0 && (
          <div className="p-16 text-center">
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Package className="text-slate-400" size={32} />
            </div>
            <p className="text-slate-500 font-medium">No products found matching your search.</p>
          </div>
        )}
      </div>

      {/* Add Product Modal (Simplified for now) */}
      {showAddModal && (
        <AddProductModal onClose={() => setShowAddModal(false)} />
      )}
    </div>
  );
};

const AddProductModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { shopId } = useAuth();
  const [formData, setFormData] = useState({
    name: '',
    brand: '',
    category: 'device',
    costPrice: 0,
    sellingPrice: 0,
    stockQuantity: 0,
    minStockLevel: 1,
    unit: 'piece',
    bottleSize: '',
    nicotineLevel: 0
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const productData = {
        ...formData,
        shopId,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      };
      
      const docRef = await addDoc(collection(db, 'products'), productData);
      
      // If e-liquid, create bottles
      if (formData.category === 'e-liquid' && formData.stockQuantity > 0) {
        const bottleSizeNum = parseInt(formData.bottleSize) || 30;
        for (let i = 0; i < formData.stockQuantity; i++) {
          await addDoc(collection(db, `products/${docRef.id}/bottles`), {
            shopId,
            bottleSize: bottleSizeNum,
            remainingMl: bottleSizeNum,
            status: 'closed',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp()
          });
        }
      }
      
      toast.success('Product added successfully');
      onClose();
    } catch (error) {
      toast.error('Failed to add product');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-white border border-slate-200 rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl animate-in zoom-in duration-300">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-10">
          <h2 className="text-xl font-bold text-slate-900">Add New Product</h2>
          <button onClick={onClose} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400"><X size={20} /></button>
        </div>
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Product Name</label>
              <input 
                required
                type="text" 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Brand</label>
              <input 
                required
                type="text" 
                value={formData.brand}
                onChange={(e) => setFormData({...formData, brand: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Category</label>
              <select 
                value={formData.category}
                onChange={(e) => setFormData({...formData, category: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              >
                <option value="device">Device</option>
                <option value="coil">Coil</option>
                <option value="e-liquid">E-Liquid</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Unit</label>
              <select 
                value={formData.unit}
                onChange={(e) => setFormData({...formData, unit: e.target.value})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              >
                <option value="piece">Piece</option>
                <option value="pack">Pack</option>
                <option value="bottle">Bottle</option>
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Cost Price (Rs)</label>
              <input 
                required
                type="number" 
                value={formData.costPrice}
                onChange={(e) => setFormData({...formData, costPrice: parseFloat(e.target.value)})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Selling Price (Rs)</label>
              <input 
                required
                type="number" 
                value={formData.sellingPrice}
                onChange={(e) => setFormData({...formData, sellingPrice: parseFloat(e.target.value)})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Initial Stock</label>
              <input 
                required
                type="number" 
                value={formData.stockQuantity}
                onChange={(e) => setFormData({...formData, stockQuantity: parseInt(e.target.value)})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Min Stock Level</label>
              <input 
                required
                type="number" 
                value={formData.minStockLevel}
                onChange={(e) => setFormData({...formData, minStockLevel: parseInt(e.target.value)})}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
              />
            </div>
          </div>

          {formData.category === 'e-liquid' && (
            <div className="p-4 bg-violet-50 border border-violet-100 rounded-xl space-y-4">
              <h3 className="text-violet-600 font-bold flex items-center gap-2 text-sm">
                <AlertCircle size={18} />
                E-Liquid Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Bottle Size (ml)</label>
                  <input 
                    type="text" 
                    placeholder="e.g. 30, 60, 100"
                    value={formData.bottleSize}
                    onChange={(e) => setFormData({...formData, bottleSize: e.target.value})}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Nicotine Level (mg)</label>
                  <input 
                    type="number" 
                    value={formData.nicotineLevel}
                    onChange={(e) => setFormData({...formData, nicotineLevel: parseInt(e.target.value)})}
                    className="w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-900 focus:ring-2 focus:ring-violet-500/20 outline-none transition-all"
                  />
                </div>
              </div>
            </div>
          )}

          <div className="flex gap-3 pt-4">
            <button 
              type="button"
              onClick={onClose}
              className="flex-1 py-3 px-4 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl transition-all uppercase tracking-widest text-xs"
            >
              Cancel
            </button>
            <button 
              type="submit"
              className="flex-1 py-3 px-4 bg-gradient-to-r from-violet-600 to-fuchsia-600 hover:from-violet-500 hover:to-fuchsia-500 text-white font-bold rounded-xl shadow-lg shadow-violet-600/20 transition-all active:scale-[0.98] uppercase tracking-widest text-xs"
            >
              Save Product
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Stock;
