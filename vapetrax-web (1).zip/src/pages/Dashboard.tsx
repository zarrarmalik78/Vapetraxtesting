import React from 'react';
import { 
  Package, 
  ShoppingCart, 
  DollarSign, 
  RefreshCw,
  Plus,
  FileDown,
  TrendingUp,
  Activity,
  Clock
} from 'lucide-react';
import { useFirestore } from '../hooks/useFirestore';
import { formatCurrency, cn } from '../lib/utils';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  Cell,
  AreaChart,
  Area
} from 'recharts';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { seedSampleData } from '../lib/seedData';
import { useAuth } from '../contexts/AuthContext';
import { where } from 'firebase/firestore';
import toast from 'react-hot-toast';

const Dashboard: React.FC = () => {
  const { shopId } = useAuth();
  const { documents: products, loading: productsLoading } = useFirestore<any>('products', where('shopId', '==', shopId));
  const { documents: sales, loading: salesLoading } = useFirestore<any>('sales', where('shopId', '==', shopId));
  const [seeding, setSeeding] = React.useState(false);

  const handleSeedData = async () => {
    if (window.confirm('This will add sample products, sales, customers, and expenses to your database. Continue?')) {
      setSeeding(true);
      try {
        if (!shopId) throw new Error('No shop ID found');
        await seedSampleData(shopId);
        toast.success('Sample data seeded successfully!');
      } catch (error) {
        toast.error('Failed to seed sample data');
      } finally {
        setSeeding(false);
      }
    }
  };

  if (productsLoading || salesLoading || seeding) {
    return <LoadingSpinner />;
  }

  // Calculate stats
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todaySales = sales.filter(s => {
    const saleDate = s.saleDate?.toDate ? s.saleDate.toDate() : new Date(s.saleDate);
    return saleDate >= today;
  });

  const todayRevenue = todaySales.reduce((acc, s) => acc + (s.totalAmount || 0), 0);
  
  // Monthly revenue (simplified)
  const thisMonth = new Date();
  thisMonth.setDate(1);
  thisMonth.setHours(0, 0, 0, 0);
  const monthlyRevenue = sales
    .filter(s => (s.saleDate?.toDate ? s.saleDate.toDate() : new Date(s.saleDate)) >= thisMonth)
    .reduce((acc, s) => acc + (s.totalAmount || 0), 0);

  // Sales Trend Data (Last 30 days)
  const last30Days = Array.from({ length: 30 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (29 - i));
    d.setHours(0, 0, 0, 0);
    return d;
  });

  const salesTrendData = last30Days.map(date => {
    const daySales = sales.filter(s => {
      const sDate = s.saleDate?.toDate ? s.saleDate.toDate() : new Date(s.saleDate);
      sDate.setHours(0, 0, 0, 0);
      return sDate.getTime() === date.getTime();
    });
    return {
      date: date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
      revenue: daySales.reduce((acc, s) => acc + (s.totalAmount || 0), 0),
      transactions: daySales.length
    };
  });

  // Category Performance Data
  const categoryData = [
    { name: 'Device', value: 780000, color: '#6366f1' },
    { name: 'Coil', value: 190000, color: '#f472b6' },
    { name: 'E-liquid', value: 85000, color: '#38bdf8' },
    { name: 'Accessory', value: 25000, color: '#22c55e' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500 pb-12">
      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 glass-card p-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-violet-600 flex items-center justify-center text-white shadow-lg shadow-violet-600/20">
            <Activity size={24} />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Analytics Dashboard</h1>
            <p className="text-slate-500 text-sm">Comprehensive business insights and performance metrics</p>
            <div className="flex items-center gap-3 mt-2">
              <span className="bg-emerald-100 text-emerald-700 px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                Live Data
              </span>
              <span className="bg-blue-100 text-blue-700 px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1.5">
                <Clock size={10} />
                PKT (UTC+5)
              </span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {products.length === 0 && (
            <button 
              onClick={handleSeedData}
              className="flex items-center gap-2 bg-violet-100 hover:bg-violet-200 text-violet-700 px-4 py-2 rounded-lg font-bold text-sm transition-all border border-violet-200"
            >
              <Plus size={18} />
              Seed Sample Data
            </button>
          )}
          <button className="flex items-center gap-2 bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-lg shadow-rose-500/20">
            <Plus size={18} />
            New Sale
          </button>
          <button className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-lg shadow-emerald-600/20">
            <FileDown size={18} />
            Export Report
          </button>
          <button className="flex items-center gap-2 bg-cyan-500 hover:bg-cyan-600 text-white px-4 py-2 rounded-lg font-semibold text-sm transition-all shadow-lg shadow-cyan-500/20">
            <RefreshCw size={18} />
            Refresh
          </button>
        </div>
      </div>

      {/* KPI Section */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 px-2">
          <TrendingUp className="text-violet-600" size={24} />
          <h2 className="text-xl font-bold text-slate-900">Key Performance Indicators</h2>
          <span className="text-slate-400 text-sm ml-auto">Real-time business metrics at a glance</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <MetricCard 
            title="MONTHLY REVENUE" 
            value={formatCurrency(monthlyRevenue)} 
            icon={<TrendingUp size={20} className="text-violet-600" />} 
            trend="+882.4%"
            isUp={true}
          />
          <MetricCard 
            title="TODAY'S SALES" 
            value={todaySales.length} 
            icon={<ShoppingCart size={20} className="text-emerald-600" />} 
            trend="+0%"
            isUp={true}
          />
          <MetricCard 
            title="TODAY'S REVENUE" 
            value={formatCurrency(todayRevenue)} 
            icon={<DollarSign size={20} className="text-blue-600" />} 
            trend="Daily"
            isUp={true}
          />
          <MetricCard 
            title="TOTAL PRODUCTS" 
            value={products.length} 
            icon={<Package size={20} className="text-orange-600" />} 
            trend="Stable"
            isUp={true}
          />
        </div>
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 glass-card p-6">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <Activity className="text-blue-600" size={20} />
              <h3 className="text-lg font-bold text-slate-900">Sales Trend (Last 30 Days)</h3>
            </div>
            <div className="flex items-center gap-4 text-[10px] font-bold uppercase tracking-wider">
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-1 bg-blue-500 rounded-full"></div>
                <span className="text-slate-500">Revenue (Rs)</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className="w-3 h-1 bg-fuchsia-400 rounded-full"></div>
                <span className="text-slate-500">Transactions</span>
              </div>
            </div>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={salesTrendData}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                <XAxis 
                  dataKey="date" 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  dy={10}
                />
                <YAxis 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                  tickFormatter={(value) => `${value/1000}k`}
                />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '12px', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                />
                <Area 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#3b82f6" 
                  strokeWidth={3}
                  fillOpacity={1} 
                  fill="url(#colorRevenue)" 
                />
                <Area 
                  type="monotone" 
                  dataKey="transactions" 
                  stroke="#e879f9" 
                  strokeWidth={3}
                  fill="none"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="glass-card p-6">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-lg font-bold text-slate-900">Category Performance</h3>
          </div>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} layout="vertical" margin={{ left: 20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" horizontal={false} />
                <XAxis type="number" hide />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  stroke="#94a3b8" 
                  fontSize={10} 
                  tickLine={false} 
                  axisLine={false}
                />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '12px' }}
                />
                <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={40}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 flex flex-wrap gap-4 justify-center">
            {categoryData.map((item) => (
              <div key={item.name} className="flex items-center gap-2 text-[10px] font-bold text-slate-500 uppercase">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: item.color }}></div>
                {item.name}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Footer Badge */}
      <div className="flex justify-center pt-4">
        <div className="bg-gradient-to-r from-violet-600 to-fuchsia-600 p-[1px] rounded-full shadow-lg shadow-violet-600/20">
          <div className="bg-white/90 backdrop-blur-sm px-6 py-1.5 rounded-full text-[10px] font-bold text-violet-700 uppercase tracking-widest">
            Powered by Zynta Tech
          </div>
        </div>
      </div>
    </div>
  );
};

const MetricCard: React.FC<{ title: string, value: string | number, icon: React.ReactNode, trend: string, isUp: boolean }> = ({ title, value, icon, trend, isUp }) => (
  <div className="glass-card p-6 hover:translate-y-[-4px] transition-all group">
    <div className="flex items-center justify-between mb-4">
      <div className="w-12 h-12 rounded-2xl bg-slate-50 flex items-center justify-center group-hover:bg-violet-50 transition-colors">
        {icon}
      </div>
      <div className={cn(
        "flex items-center gap-1 px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest",
        isUp ? "bg-emerald-50 text-emerald-600" : "bg-red-50 text-red-600"
      )}>
        {trend}
      </div>
    </div>
    <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-1">{title}</p>
    <p className="text-3xl font-bold text-slate-900">{value}</p>
  </div>
);

export default Dashboard;
