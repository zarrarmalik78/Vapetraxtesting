import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Package, 
  ShoppingCart, 
  History, 
  Users, 
  CreditCard, 
  Factory, 
  Download, 
  DollarSign, 
  BarChart3, 
  FileText, 
  ClipboardList, 
  Settings, 
  LogOut,
  Menu,
  X,
  Search,
  Code,
  Palette,
  ShieldCheck,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useDocument } from '../../hooks/useFirestore';
import { cn } from '../../lib/utils';

const Sidebar: React.FC = () => {
  const { currentUser, userRole, shopId, logout } = useAuth();
  const { document: settings } = useDocument<any>('settings', shopId || 'shop_settings');
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const navigate = useNavigate();

  const shopName = settings?.shopName || 'VapeTrax';
  const shopLogo = settings?.shopLogo;

  const navItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard, roles: ['admin', 'cashier'] },
    { name: 'Sales', path: '/sales', icon: ShoppingCart, roles: ['admin', 'cashier'] },
    { name: 'Analytics', path: '/analytics', icon: BarChart3, roles: ['admin', 'cashier'] },
    { name: 'Detailed Reports', path: '/reports/detailed', icon: FileText, roles: ['admin'] },
    { name: 'Purchases', path: '/purchases', icon: Download, roles: ['admin'] },
    { name: 'Products', path: '/stock', icon: Package, roles: ['admin', 'cashier'] },
    { name: 'Suppliers', path: '/suppliers', icon: Factory, roles: ['admin'] },
    { name: 'Customers', path: '/customers', icon: Users, roles: ['admin', 'cashier'] },
    { name: 'Expenses', path: '/expenses', icon: DollarSign, roles: ['admin'] },
    { name: 'Inventory Logs', path: '/inventory-logs', icon: ClipboardList, roles: ['admin', 'cashier'] },
  ];

  const bottomItems = [
    { name: 'Global Search', path: '/search', icon: Search, roles: ['admin', 'cashier'] },
    { name: 'About Developers', path: '/about', icon: Code, roles: ['admin', 'cashier'] },
    { name: 'Theme Options', path: '/theme', icon: Palette, roles: ['admin'] },
    { name: 'License', path: '/license', icon: ShieldCheck, roles: ['admin'] },
    { name: 'Settings', path: '/settings', icon: Settings, roles: ['admin'] },
  ];

  const filteredNavItems = navItems.filter(item => item.roles.includes(userRole || ''));
  const filteredBottomItems = bottomItems.filter(item => item.roles.includes(userRole || ''));

  const handleLogout = async () => {
    await logout();
    navigate('/login');
  };

  return (
    <>
      {/* Mobile Menu Button */}
      <button 
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-violet-600 rounded-lg text-white"
        onClick={() => setMobileOpen(!mobileOpen)}
      >
        {mobileOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Sidebar Overlay */}
      {mobileOpen && (
        <div 
          className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={cn(
        "fixed top-0 left-0 h-full bg-white border-r border-slate-200 z-40 transition-all duration-300 flex flex-col",
        collapsed ? "w-20" : "w-64",
        mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
      )}>
        {/* Logo Section */}
        <div className="p-6 flex flex-col items-center">
          <div className="w-full flex items-center justify-between mb-6">
            {!collapsed && (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 flex items-center justify-center bg-violet-600 rounded-lg shadow-lg shadow-violet-600/20 overflow-hidden">
                  {shopLogo ? (
                    <img src={shopLogo} alt="Logo" className="w-full h-full object-contain" />
                  ) : (
                    <svg viewBox="0 0 24 24" className="w-5 h-5 text-white fill-current">
                      <path d="M12 2L4.5 20.29L5.21 21L12 18L18.79 21L19.5 20.29L12 2Z" />
                    </svg>
                  )}
                </div>
                <span className="text-lg font-bold text-slate-900 tracking-tight">{shopName}</span>
              </div>
            )}
            <button 
              className="hidden lg:block p-1.5 hover:bg-slate-100 rounded-lg text-slate-400"
              onClick={() => setCollapsed(!collapsed)}
            >
              {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
            </button>
          </div>

          {!collapsed && (
            <div className="w-full flex flex-col items-center text-center mb-6">
              <div className="w-16 h-16 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 p-0.5 mb-3 shadow-lg shadow-violet-500/20 overflow-hidden">
                <div className="w-full h-full rounded-full bg-white flex items-center justify-center font-bold text-violet-600 text-xl overflow-hidden">
                  {shopLogo ? (
                    <img src={shopLogo} alt="Logo" className="w-full h-full object-contain" />
                  ) : (
                    currentUser?.email?.charAt(0).toUpperCase() || 'V'
                  )}
                </div>
              </div>
              <h3 className="text-slate-900 font-bold text-lg leading-tight">{shopName}</h3>
              <p className="text-slate-500 text-xs mb-3 font-medium uppercase tracking-wider">Premium Management</p>
              <div className="bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full text-[10px] font-bold flex items-center gap-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                Active Session
                <span className="opacity-60">Admin</span>
              </div>
            </div>
          )}
        </div>

        {/* Navigation */}
        <div className="flex-1 overflow-y-auto px-4 py-2 space-y-1 scrollbar-none">
          {filteredNavItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all group",
                isActive 
                  ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              )}
              onClick={() => setMobileOpen(false)}
            >
              <item.icon size={20} className={cn(
                "min-w-[20px]",
                collapsed ? "mx-auto" : ""
              )} />
              {!collapsed && <span className="text-sm font-bold uppercase tracking-wider">{item.name}</span>}
            </NavLink>
          ))}

          <div className="pt-4 pb-2">
            <div className="h-px bg-slate-100 mx-2"></div>
          </div>

          {filteredBottomItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all group",
                isActive 
                  ? "bg-violet-600 text-white shadow-lg shadow-violet-600/20" 
                  : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
              )}
              onClick={() => setMobileOpen(false)}
            >
              <item.icon size={20} className={cn(
                "min-w-[20px]",
                collapsed ? "mx-auto" : ""
              )} />
              {!collapsed && <span className="text-sm font-bold uppercase tracking-wider">{item.name}</span>}
            </NavLink>
          ))}

          <button
            onClick={handleLogout}
            className={cn(
              "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-slate-500 hover:bg-rose-50 hover:text-rose-600 group",
              collapsed ? "justify-center" : ""
            )}
          >
            <LogOut size={20} className="min-w-[20px]" />
            {!collapsed && <span className="text-sm font-bold uppercase tracking-wider">Logout</span>}
          </button>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
